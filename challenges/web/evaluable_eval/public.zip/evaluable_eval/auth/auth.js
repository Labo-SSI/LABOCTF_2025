import express from 'express';
import cookieSession from 'cookie-session';

const router = express.Router();

const users = {
    admin: 'admin'
};
const localIPs = ['127.0.0.1', '::1', '::ffff:127.0.0.1', 'localhost', 'firefox.fr', '0:0:0:0:0:ffff:127.0.0.1'];

router.use(cookieSession({
    name: 'session',
    keys: [process.env.SESSION_SECRET],
    maxAge: 24 * 60 * 60 * 1000
}));

export const requireAuth = (req, res, next) => {
    if (!req.session.isAdmin) {
        return res.redirect('/login');
    }
    next();
};

router.get('/login', (req, res) => {
    if (req.session.isAdmin) {
        return res.redirect('/');
    }
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Login</title>
            <style>
                body {
                    font-family: system-ui, -apple-system, sans-serif;
                    background-color: #F3F4F6;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    margin: 0;
                }
                .container {
                    background: white;
                    padding: 2rem;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                    width: 100%;
                    max-width: 400px;
                }
                h1 {
                    margin: 0 0 1.5rem 0;
                    text-align: center;
                    color: #111827;
                }
                .form-group {
                    margin-bottom: 1rem;
                }
                label {
                    display: block;
                    margin-bottom: 0.5rem;
                    color: #374151;
                }
                input {
                    width: 100%;
                    padding: 0.5rem;
                    border: 1px solid #D1D5DB;
                    border-radius: 4px;
                    box-sizing: border-box;
                }
                button {
                    width: 100%;
                    padding: 0.75rem;
                    background-color: #2563EB;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-weight: 500;
                }
                button:hover {
                    background-color: #1D4ED8;
                }
                .error {
                    color: #DC2626;
                    margin-top: 1rem;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Login Required</h1>
                <form id="loginForm">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input name="username" type="text" id="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input name="password" type="password" id="password" required>
                    </div>
                    <button type="submit">Login</button>
                    <div id="error" class="error"></div>
                </form>
            </div>
            <script>
                const form = document.getElementById('loginForm');
                const error = document.getElementById('error');

                form.addEventListener('submit', async (e) => {
                    e.preventDefault();
                    const formData = new FormData(form);
                    try {
                        const response = await fetch('/api/auth', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                username: formData.get('username'),
                                password: formData.get('password')
                            }),
                        });
                        
                        if (response.redirected) {
                            window.location.href = response.url;
                        } else {
                            const text = await response.text();
                            error.textContent = text;
                        }
                    } catch (err) {
                        error.textContent = 'An error occurred';
                    }
                });
            </script>
        </body>
        </html>
    `);
});

router.post('/api/auth', (req, res) => {

    // chatgpt made this code, it should be safe
    if (req.body.username === 'admin' && !localIPs.includes(req.ip)) {
        return res.send('Admin is only allowed from localhost');
    }
    const auth = Object.assign({}, req.body);
    if (users[auth.username] === auth.password) {
        if (auth.username === 'admin') {
            req.session.isAdmin = true;
            res.redirect('/');
        } else {
            res.send('Access denied');
        }
    } else {
        res.send('Invalid username or password');
    }
});

export default router;