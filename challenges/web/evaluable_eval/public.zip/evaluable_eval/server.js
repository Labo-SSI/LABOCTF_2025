// server.js
import express from 'express';
import * as astParser from "@babel/parser";
import astTraverse from "@babel/traverse";
import * as codeMin from "babel-minify";
import authRouter, { requireAuth } from './auth/auth.js';

const shrink = codeMin.default;
const examineAST = astTraverse.default;
const server = express();

server.use(express.json());
server.use('/', authRouter);
server.get('/', requireAuth, (req, res) => {
    res.sendFile('index.html', { root: 'public' });
});

server.use(requireAuth, express.static('public'));

const wrapConsole = async (operation) => {
    const buffer = new Set();
    const defaultPrint = console.log;
    console.log = (...data) => buffer.add(data.join(' '));
    
    let outcome;
    try {
        outcome = operation();
        await new Promise(resolve => setTimeout(resolve, 100));
    } catch(e) {
        outcome = { code: 422, message: "Unexpected error" };
    }
    
    console.log = defaultPrint;
    return { 
        buffer: Array.from(buffer), 
        outcome 
    };
};

class Sandbox {
    IsSecure(snippet) {
        return astParser.parse(snippet, {
            sourceType: "module",
            plugins: [],
        });
    }

    inspect(program) {
        let danger = false;
        examineAST(program, {
            "CallExpression|AssignmentExpression": {
                enter(p) {
                    danger = true;
                    p.stop();
                }
            }
        });
        return !danger;
    }

    compact(snippet) {
        const out = shrink(snippet, {});
        if (out.error) throw out.error;
        return out;
    }

    validate(input) {
        try {
            const tree = this.IsSecure(input);
            if (!this.inspect(tree)) {
                throw new Error("Don't try to hack me >:(");
            }

            const compressed = this.compact(input);
            if (!compressed.code) {
                throw new Error("Code minification failed");
            }

            const candidate = compressed.code.length < input.length ? 
                            compressed.code : input;
            
            if (candidate.length > 30) {
                return { code: 413, message: "I can't handle that much code daddy UwU" };
            }

            try {
                eval(candidate);
                return { code: 200 };
            } catch {
                return { code: 422, message: "Unexpected error" };
            }
        } catch (e) {
            return { code: 400, message: e.message };
        }
    }
}

const runtime = new Sandbox();

server.post('/api/evaluate', requireAuth, async (req, res) => {
    const snippet = req.body.code;
    
    if (!snippet?.trim()) {
        return res.status(400).json({ 
            message: 'Missing input',
            output: [] 
        });
    }
    
    const { buffer, outcome } = await wrapConsole(() => runtime.validate(snippet));
    
    if (outcome.code === 200) {
        return res.json({ output: buffer });
    }
    
    res.status(outcome.code).json({ 
        message: outcome.message, 
        output: buffer 
    });
});

const PORT = process.env.PORT ?? 3000;
server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});